"""ComfyUI node definitions."""
